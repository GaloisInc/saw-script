pub fn i_found_something(x: u32) -> Option<u32> {
    Some(x)
}

pub fn i_got_nothing() -> Option<u32> {
    None
}

pub fn do_stuff_with_option(o: Option<u32>) {
    // ...
}
