class Add {
    public static int add(int x, int y) {
        return x + y;
    }

    public static int dbl(int x) {
        return add(x, x);
    }
}
