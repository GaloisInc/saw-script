int double_ref(int x) {
    return x * 2;
}

int double_imp(int x) {
    return x << 1;
}
